<?php

namespace App\Http\Controllers;

use App\Models\Orders;
use App\Models\OrderDetail;
use App\Models\StoreInventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       try{
        DB::beginTransaction();
        $orders = $request->order;
         Orders::create($orders);
         $OrderID =  DB::getPdo()->lastInsertId();
         foreach($request->product as $i){
            $OrderDetail = [
                'ProductID'=> $i['product']['ProductID'],
                'OrderID' => $OrderID,
                'Quantity' => $i['Quantity'],
                'Price' => $i['product']['Price']
            ];
           if($this->checkQuantity($i['product']['ProductID'],$orders['StoreID'],$i['Quantity'])){
            OrderDetail::create($OrderDetail); 
            $ifcreate  = true;
           }else{
            $ifcreate = false;
            return ['thisProduct' => $i,'available' => false] ;
           }
         }
        if($ifcreate) {

            DB::commit();

        }

        }catch(Exeption $e){
            DB::rollback();
            return $e;
        }
         
    }
    public function checkQuantity($ProductID,$StoreID,$Quantity)
    {
      $inventory =  StoreInventory::where('ProductID',$ProductID)->where('StoreID',$StoreID)->first();
      if($inventory)
      {
           if($inventory->Quantity > 0 && $Quantity <= $inventory->Quantity ){
              return true;
          }else {
            return false;
          }
      }else{
          return 'no_inventory';
      }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function show(Orders $orders)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function edit(Orders $orders)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Orders $orders)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function destroy(Orders $orders)
    {
        //
    }
    public function viewMyOrder(Request $request)
    {
        
        return DB::select('SELECT * FROM dbo.orders WHERE dbo.orders.UserID = ? ORDER BY dbo.orders.SeleDate DESC ', [$request->UserID]);
    }
    public function orderDetail(Request $request)
    {
       return DB::select('SELECT * FROM dbo.order_details  INNER JOIN dbo.products ON dbo.products.ProductID = dbo.order_details.ProductID WHERE dbo.order_details.OrderID = ?', [$request->OrderID]);
    }
}
