<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page = $request->page;
       
        $size = $request->size;
        $data = DB::select('SELECT * FROM dbo.products INNER JOIN dbo.categories ON dbo.products.CategoryID = dbo.categories.CategoryID WHERE dbo.products.Status = 1');
        $collect = collect($data);
        return [
            "Product" => $collect->forPage($page, $size),
            "Count" => $collect->count(),
            "Size" => $size,
            "Page" => $page
        ];
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        return Products::create($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Products  $products
     * @return \Illuminate\Http\Response
     */
    public function show(Products $products)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Products  $products
     * @return \Illuminate\Http\Response
     */
    public function edit(Products $products)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Products  $products
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Products $products)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Products  $products
     * @return \Illuminate\Http\Response
     */
    public function destroy(Products $products)
    {
        //
    }
    public function searchProduct(Request $request)
    {
        $page = $request->page;
        $size = $request->size;
        $data = DB::select('SELECT * FROM dbo.products INNER JOIN dbo.categories ON dbo.products.CategoryID = dbo.categories.CategoryID WHERE dbo.products.Status = 1 AND  dbo.products.ProductName LIKE ? ', ["%" . $request->search . "%"]);
        $collect = collect($data);
        return [
            "Product" => $collect->forPage($page, $size),
            "Count" => $collect->count(),
            "Size" => $size,
            "Page" => $page
        ];
    }
    public function product($ProductID)
    {
        $data = DB::select('SELECT * FROM dbo.products  INNER JOIN dbo.categories ON dbo.products.CategoryID = dbo.categories.CategoryID WHERE dbo.products.Status = 1 AND dbo.products.ProductID = ?',[$ProductID]);
        return ['product' => $data];
    }
    public function ishot()
    {
        return Products::where('isHot',true)->get();
    }
    public function storeInventory(Request $request)
    {
        $page = $request->page;
       
        $size = $request->size;
        $data = DB::select('SELECT * FROM dbo.products INNER JOIN dbo.store_inventories ON dbo.products.ProductID = dbo.store_inventories.ProductID INNER JOIN dbo.categories ON dbo.products.CategoryID = dbo.categories.CategoryID WHERE dbo.products.Status = 1 AND dbo.store_inventories.StoreID = ?',[$request->StoreID]);
        $collect = collect($data);
        return [
            "Product" => $collect->forPage($page, $size),
            "Count" => $collect->count(),
            "Size" => $size,
            "Page" => $page
        ];
    }
    public function isHotStore(Request $request)
    {
        return DB::select('SELECT * FROM dbo.products INNER JOIN dbo.store_inventories ON dbo.products.ProductID = dbo.store_inventories.ProductID INNER JOIN dbo.categories ON dbo.products.CategoryID = dbo.categories.CategoryID WHERE dbo.products.Status = 1 AND dbo.products.isHot = ? AND dbo.store_inventories.StoreID = ?',[true,$request->StoreID]);
    }
    public function available(Request $request)
    {
        return DB::select('SELECT * FROM dbo.stores INNER JOIN dbo.store_inventories ON dbo.store_inventories.StoreID = dbo.stores.StoreID WHERE dbo.store_inventories.ProductID = ?', [$request->ProductID]);
    }
}
