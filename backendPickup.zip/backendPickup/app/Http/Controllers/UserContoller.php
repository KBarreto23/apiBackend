<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class UserContoller extends Controller
{
    public function store(Request $request)
    {
         
         $data  = $request->all();
         $data['Password'] = encrypt($request->Password);
         return User::create($data);
         
    }
    public function login(Request $request)
    {
        $user = User::where('Email',$request->Email)->first();
        if($user){
            if($request->Password == decrypt($user->Password)){
                $token = Str::random(70).time();
                DB::table('users')->where('UserID', $user['UserID'])->update(['api_token' => $token]);
                return ['user' => $user , 'token' => $token ,'login' => true ];
            }
        }
        else{
            return ['login' => false];
        }
    }
    public function logout()
    {
        $user = auth()->user();
        $user->api_token = null;
        return $user->save();        
    }
}
