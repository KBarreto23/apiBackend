<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserContoller;
use App\Http\Controllers\CategoriesController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\CartsController;
use App\Http\Controllers\StoreInventoryController;
use App\Http\Controllers\OrdersController;

//
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
//user
Route::post('crateUser',[UserContoller::class, 'store']);//create user
Route::post('login',[UserContoller::class, 'login']);//create user

Route::get('search',[ProductsController::class,'searchProduct']);
Route::get('allProduct',[ProductsController::class , 'index']);
Route::get('product/{ProductID}',[ProductsController::class, 'product']);
Route::get('isHot',[ProductsController::class, 'ishot']);
Route::get('store',[StoreController::class,'index']);
Route::get('storeInventory',[ProductsController::class,'storeInventory']);
Route::get('isHotStore',[ProductsController::class, 'isHotStore']);
Route::get('available',[ProductsController::class,'available']);


Route::get('viewStore',[StoreController::class,'index']);

//SECURITY ROUTE 
Route::group(['middleware' => 'auth:api'], function () {

    //user 
    Route::post('logout',[UserContoller::class , 'logout']);

    //product 
    Route::post('createCategory',[CategoriesController::class,'store']);
    Route::post('createProduct',[ProductsController::class,'store']);
   

    //Cart 
    Route::post('cart',[CartsController::class,'store']);
    Route::get('mycart/{UserID}',[CartsController::class , 'viewMyCart']);
    Route::post('deleteCart',[CartsController::class,'deletCart']);
    Route::post('updateCart',[CartsController::class,'update']);
    Route::post('emptyCart/{UserID}',[CartsController::class,'emptyCart']);

    //store 
    Route::post('createstore',[StoreController::class,'store']);
    Route::post('createInventory',[StoreInventoryController::class, 'store']);
    Route::post('updatestore/{StoreID}',[StoreController::class,'update']);
    Route::post('deleteStore/{StoreID}',[StoreController::class,'deleteStore']);


    //order 
    Route::post('createOrder',[OrdersController::class,'store']);

    Route::get('myOrders',[OrdersController::class,'viewMyOrder']);
    Route::get('orderDetail',[OrdersController::class,'orderDetail']);
    

});




