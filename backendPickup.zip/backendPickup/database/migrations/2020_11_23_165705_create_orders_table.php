<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('OrderID');
            $table->bigInteger('UserID');
            $table->double('Total');
            $table->bigInteger('ApprovalNumber');
            $table->bigInteger('StoreID');
            $table->double('TotalTax');
            $table->string('SeleDate');
            $table->string('SaleHour');
            $table->string('PaymenthMethod');
            $table->foreign('StoreID')->references('StoreID')->on('stores');
            $table->foreign('UserID')->references('UserID')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
