<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('UserID');
            $table->string('Name');
            $table->string('LastName');
            $table->string('Email')->unique();
            $table->string('Password');
            $table->string('api_token', 80)->nullable()->default(null);
            $table->string('Address');
            $table->string('ZipCode');
            $table->string('State');
            $table->string('Role');
        
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
